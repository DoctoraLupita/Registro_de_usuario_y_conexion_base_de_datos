

<?php

include 'conexion_be.php';

$nombre_completo = $_POST['nombre_completo'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$contrasena = $_POST['contrasena'];

// Encriptamiento de contraseña
$contrasena_hash = hash('sha512', $contrasena);

// Verificar que correo no se repita en BD
$verificar_correo = mysqli_query($conexion, "SELECT * FROM usuarios WHERE correo = '$correo'");

if(mysqli_num_rows($verificar_correo) > 0) {
    echo '
    <script>
        alert("Este correo ya está registrado, intenta con otro correo diferente");
        window.location = "../index.php";
    </script>';
    exit();
}

// Verificar que usuario no se repita en BD
$verificar_usuario = mysqli_query($conexion, "SELECT * FROM usuarios WHERE usuario = '$usuario'");

if(mysqli_num_rows($verificar_usuario) > 0) {
    echo "
    <script>
        alert('Este usuario ya está registrado, intenta con otro usuario diferente');
        window.location = '../index.php';
    </script>";
    exit();
}

// Construir la consulta de inserción
$query = "INSERT INTO usuarios(nombre_completo, correo, usuario, contrasena) 
          VALUES('$nombre_completo', '$correo', '$usuario', '$contrasena_hash')";

// Ejecutar la consulta de inserción
$resultado = mysqli_query($conexion, $query);

// Verificar si la consulta se ejecutó con éxito
if ($resultado) {
    echo "
    <script>
        alert('Usuario insertado correctamente');
        window.location = '../index.php';
    </script>";
} else {
    echo "Error al insertar el registro: " . mysqli_error($conexion);
}

// Cerrar la conexión
mysqli_close($conexion);

?>
