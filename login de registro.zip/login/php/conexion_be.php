<?php

// Datos de conexión a la base de datos
//$servidor = "localhost";
$servidor = "127.0.0.1:3307";
$usuario = "root";
$contrasena = "login123";
//$nombre_bd = "login_register_db";
$nombre_bd = "test";

// Crear una conexión
$conexion = new mysqli($servidor, $usuario, $contrasena, $nombre_bd);
//$conexion = new mysqli('127.0.0.1:3307','root','login123','login_register_db');



// Verificar la conexión

if($conexion->connect_error) {
    die("Error de conexión: " . $conexion->connect_error);
}

// Si la conexión es exitosa, puedes seguir ejecutando consultas o realizar otras operaciones con la base de datos
 