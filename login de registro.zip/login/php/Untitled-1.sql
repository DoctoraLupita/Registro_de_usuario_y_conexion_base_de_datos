SELECT * FROM usuarios;
 